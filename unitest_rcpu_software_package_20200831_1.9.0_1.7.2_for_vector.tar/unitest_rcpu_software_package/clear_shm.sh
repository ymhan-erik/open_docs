#!/bin/bash
echo "=========  Clear share memory =========="
ipcs -m | grep 0x | awk '{printf(" -M %s", $1)}' | xargs ipcrm
echo "=========  Finished   =========="

