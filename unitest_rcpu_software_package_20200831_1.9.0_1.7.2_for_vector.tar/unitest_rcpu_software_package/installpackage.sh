#!/bin/bash

rm -f /etc/fstab
cp ./fstab /etc/

/etc/init.d/S90rcpumgr stop
#/etc/init.d/S95rcpumgrmon stop
#/etc/init.d/S80insunimod stop
#/etc/init.d/S60nfsmount stop

#rm -f /etc/init.d/S60nfsmount
#cp ./S60nfsmount /etc/init.d/

rm -f /etc/init.d/S80insunimod
cp ./S80insunimod /etc/init.d/

rm -f /etc/init.d/S90rcpumgr
cp ./S90rcpumgr /etc/init.d/

#rm -f /etc/init.d/S95rcpumgrmon
#cp ./S95rcpumgrmon /etc/init.d/

rm -f /root/unitest-sram.ko
#cp -i ./unitest-sram.ko /root/
cp ./unitest-sram.ko /root/

#cp -i ./rcpu.conf /root/
rm -f /root/fmver.ini
cp ./fmver.ini /root/

rm -f /usr/bin/rcpumgr
cp ./rcpumgr /usr/bin/

#rm -f /usr/bin/rcpumgrmon
#cp ./rcpumgrmon /usr/bin/

rm -f /usr/lib/librcpu.so*
cp ./librcpu.so.* /usr/lib/
ln -s /usr/lib/librcpu.so.* /usr/lib/librcpu.so

#/etc/init.d/S60nfsmount start
#/etc/init.d/S80insunimod start
#/etc/init.d/S90rcpumgr start
