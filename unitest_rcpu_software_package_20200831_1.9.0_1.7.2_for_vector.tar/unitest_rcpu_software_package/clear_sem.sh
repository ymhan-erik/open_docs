#!/bin/bash
echo "=========  Clear Semaphore =========="
ipcs -s | grep 0x | awk '{printf(" -S %s", $1)}' | xargs ipcrm
echo "=========  Finished   =========="

