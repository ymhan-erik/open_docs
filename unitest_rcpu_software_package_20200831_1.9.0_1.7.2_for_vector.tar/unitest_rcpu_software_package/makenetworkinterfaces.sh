#!/bin/bash

rm -rf /etc/network/interfaces

echo "\
# Configure Loopback
auto lo
iface lo inet loopback


auto eth0
iface eth0 inet static
        address $1.$2
        netmask 255.255.255.0
        network $1.0
        broadcast $1.255
        gateway $1.1" >> /etc/network/interfaces

sync
sync
