#!/bin/bash
echo "=========  Clear Semaphore & share memory =========="
ipcs -s | grep 0x | awk '{printf(" -S %s", $1)}' | xargs ipcrm
ipcs -m | grep 0x | awk '{printf(" -M %s", $1)}' | xargs ipcrm
echo "=========  Finished   =========="

