#!/bin/bash
echo "=========  Clear Shared Memory for FM_RW_Sync=========="
ipcs -m | grep 0x00001234 | awk '{printf(" -M %s", $1)}' | xargs ipcrm
echo "=========  Finished   =========="

