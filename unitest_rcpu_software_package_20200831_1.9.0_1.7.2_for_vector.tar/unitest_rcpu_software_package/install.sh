#!/bin/bash
cd /root/unitest_rcpu_software_package/
./makercpuconf.sh $1 $2 $3
./installpackage.sh
