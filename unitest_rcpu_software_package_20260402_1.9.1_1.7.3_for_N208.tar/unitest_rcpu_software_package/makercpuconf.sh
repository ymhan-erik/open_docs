#!/bin/bash

rm -rf /root/rcpu.conf
#rm -rf /home/unin2/UNIN2_RCPU_SOURCE/unitest_rcpu_software_package/rcpu.conf

echo "\
PGB   $1
RCPU  $2
COLs  16
ROWs  12
RCPUs 4
IP    $3
PORT  $4
COMMON_SHM_SIZE   400000000 
EACH_DUT_SHM_SIZE 2000000" >>  /root/rcpu.conf #/home/unin2/UNIN2_RCPU_SOURCE/unitest_rcpu_software_package/rcpu.conf

sync
sync

rm -f /etc/init.d/S60nfsmount

echo "\
#!/bin/sh
#
# Start NFS mount.
#

start(){
	/bin/mount -t nfs $3:/home/unin2/NFS /root/nfs -o rw,rsize=1024,wsize=1024,nolock
}

stop(){
	/bin/umount -f /root/nfs
}

restart(){
	stop
	start
}

case \"\$1\" in
	start)
		start
		;;
	stop)
		stop
		;;
	restart|reload)
		restart
		;;
	*)

		echo \"Usage: \$0 {start|stop|restart}\"
		exit 1
esac

exit \$?
" >>  /etc/init.d/S60nfsmount

sync
sync

chmod 755 /etc/init.d/S60nfsmount
