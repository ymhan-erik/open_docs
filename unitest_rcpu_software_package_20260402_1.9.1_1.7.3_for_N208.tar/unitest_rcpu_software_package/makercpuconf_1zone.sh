#!/bin/bash

rm -rf /root/rcpu.conf
#rm -rf /home/unin2/UNIN2_RCPU_SOURCE/unitest_rcpu_software_package/rcpu.conf

echo "\
PGB   $1
RCPU  $2
COLs  16
ROWs  12
RCPUs 4
IP    10.0.0.99
PORT  $3
COMMON_SHM_SIZE   400000000 
EACH_DUT_SHM_SIZE 2000000" >>  /root/rcpu.conf #/home/unin2/UNIN2_RCPU_SOURCE/unitest_rcpu_software_package/rcpu.conf
